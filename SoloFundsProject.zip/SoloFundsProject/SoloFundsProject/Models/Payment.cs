﻿using SoloFundsProject.Models.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SoloFundsProject.Models
{
    public class Payment : IPayment
    {
        public Payment()
        {

        }       
        public int Id { get; set; }
        public DateTime LoanStartDate { get; set; }
        public DateTime ActualPaybackDate { get; set; }
        public Decimal ActualTipAmount { get; set; }
        public Decimal DonationAmount { get; set; }
        public Decimal PaybackAmount { get; set; }

        public IEnumerable<T> GetLoanPaymentsByBorrower<T>(int userId) where T : class
        {
            throw new NotImplementedException();
        }

        public IEnumerable<T> GetLoanPaymentsByLender<T>(int userId) where T : class
        {
            throw new NotImplementedException();
        }

        public IEnumerable<T> GetTipAmountsByBorrower<T>(int userId) where T : class
        {
            throw new NotImplementedException();
        }
        public void Dispose()
        {
            throw new NotImplementedException();
        }
    }
}