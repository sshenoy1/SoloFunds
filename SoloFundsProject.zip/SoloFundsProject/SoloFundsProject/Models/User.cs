﻿using SoloFundsProject.Models.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SoloFundsProject.Models
{
    public class User :IUser
    {
        public User()
        {

        }
        public int Id { get; set; }

        public int SoloScore { get; set; }

        public int GetSoloScore(int userId)
        {
            throw new NotImplementedException();
        }
        public void Dispose()
        {
            throw new NotImplementedException();
        }        
    }
}