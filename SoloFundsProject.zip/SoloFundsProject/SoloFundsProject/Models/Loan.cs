﻿using SoloFundsProject.Models.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SoloFundsProject.Models
{
    public class Loan : ILoan
    {   
        public Loan()
        {

        }

        public int Id { get; set; }
        public Decimal LoanAmount { get; set; }
        public int LoanTerm { get; set; }
        public Decimal TipAmount { get; set; }
        public DateTime LoanCreationDate { get; set; }
        public DateTime PaybackDate { get; set; }               

        public IEnumerable<T> GetAllLoans<T>() where T : class
        {
            throw new NotImplementedException();
        }

        public IEnumerable<T> GetLoansByLoanAmount<T>() where T : class
        {
            throw new NotImplementedException();
        }

        public IEnumerable<T> GetLoansByLoanTerm<T>() where T : class
        {
            throw new NotImplementedException();
        }

        public IEnumerable<T> GetLoansByPaybackDate<T>() where T : class
        {
            throw new NotImplementedException();
        }

        public IEnumerable<T> GetLoansBySoloScore<T>() where T : class
        {
            throw new NotImplementedException();
        }

        public IEnumerable<T> GetLoansByTipAmount<T>() where T : class
        {
            throw new NotImplementedException();
        }
        public void Dispose()
        {
            throw new NotImplementedException();
        }
    }
}