﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoloFundsProject.Models.Interfaces
{
    public interface IUser : IDisposable
    {
        int GetSoloScore(int userId);
    }
}
