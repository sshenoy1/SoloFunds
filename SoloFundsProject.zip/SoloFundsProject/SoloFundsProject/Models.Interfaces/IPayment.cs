﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoloFundsProject.Models.Interfaces
{
    public interface IPayment : IDisposable
    {
        IEnumerable<T> GetLoanPaymentsByLender<T>(int userId) where T : class;
        IEnumerable<T> GetLoanPaymentsByBorrower<T>(int userId) where T : class;
        IEnumerable<T> GetTipAmountsByBorrower<T>(int userId) where T : class;
    }
}
