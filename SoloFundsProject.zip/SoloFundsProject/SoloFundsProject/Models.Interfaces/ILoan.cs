﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoloFundsProject.Models.Interfaces
{
    public interface ILoan :IDisposable
    {
        IEnumerable<T> GetAllLoans<T>() where T : class;
        IEnumerable<T> GetLoansByLoanAmount<T>() where T : class;
        IEnumerable<T> GetLoansByLoanTerm<T>() where T : class;
        IEnumerable<T> GetLoansByPaybackDate<T>() where T : class;
        IEnumerable<T> GetLoansBySoloScore<T>() where T : class;
        IEnumerable<T> GetLoansByTipAmount<T>() where T : class;
    }
}
