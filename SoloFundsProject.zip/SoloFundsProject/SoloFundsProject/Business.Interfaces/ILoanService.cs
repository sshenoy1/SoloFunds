﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoloFundsProject.Business.Interfaces
{
    public interface ILoanService : IDisposable
    {
        IEnumerable<T> GetLoansByLender<T>() where T : class;
        IEnumerable<T> GetUserPaymentHistory<T>(int userId) where T : class;
    }
}
