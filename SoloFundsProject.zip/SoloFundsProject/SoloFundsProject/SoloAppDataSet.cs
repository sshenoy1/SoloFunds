﻿namespace SoloFundsProject {
    
    
    public partial class SoloAppDataSet {


    }
}
namespace SoloFundsProject
{


    partial class DataSet
    {
    }
}
