﻿using SoloFundsProject.Business.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SoloFundsProject.Business
{
    public class LoanService : ILoanService
    {
        public IEnumerable<T> GetLoansByLender<T>() where T : class
        {
            throw new NotImplementedException();
        }

        public IEnumerable<T> GetUserPaymentHistory<T>(int userId) where T : class
        {
            throw new NotImplementedException();
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }         
    }
}