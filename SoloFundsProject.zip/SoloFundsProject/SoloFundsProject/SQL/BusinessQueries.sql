﻿--SQL Queries for retrieving data for the Mobile App Interface

------------ User Object-----------------
--GetSoloScore
SELECT u.SoloScore FROM User u
WHERE u.Id = userId


------------ Loan object ------------
-- GetAllLoans<T>()

SELECT * FROM Loan l

-- GetLoansByLoanAmount<T>()

SELECT * FROM Loan l
ORDER BY l.LoanAmount

-- GetLoansByLoanTerm<T>()

SELECT * FROM Loan l
ORDER BY l.LoanTerm

-- GetLoansByPaybackDate<T>()

SELECT * from Loan l
ORDER BY l.PaybackDate

-- GetLoansBySoloScore<T>() 

SELECT l.* FROM Loan l
JOIN User u
ON l.BorrowerId = u.Id
ORDER BY u.SoloScore

-- GetLoansByTipAmount<T>() 
SELECT * FROM Loan l
ORDER BY l.TipAmount


------------ Payment object ------------
-- GetLoanPaymentsByLender<T>(int userId)
SELECT * FROM Payment p
WHERE p.LenderId = userId
order by p.ActualPaybackDate

-- GetLoanPaymentsByBorrower<T>(int userId)
SELECT * FROM Payment p
WHERE p.BorrowerId = userId
ORDER BY p.ActualPaybackDate

-- GetTipAmountsByBorrower<T>(int userId)
SELECT p.ActualTipAmount FROM Payment p
WHERE p.BorrowerId = userId
ORDER BY p.ActualTipAmount


------------ Mobile app data queries ------------
-- GetLoansByLender<T>() 

SELECT * FROM Loan l 
JOIN User u
ON l.LenderId = u.Id
ORDER BY u.SoloScore, l.LoanAmount, l.PaybackDate

-- GetUserPaymentHistory<T>(int userId) 
SELECT p.PaybackAmount, p.ActualPaybackDate, l.LoanAmount FROM Payment p
JOIN Loan l 
ON p.LoanId = l.Id
WHERE p.BorrowerId = userId
GROUP BY l.LoanAmount, p.PaybackAmount, p.ActualPaybackDate
ORDER BY p.ActualPaybackDate

